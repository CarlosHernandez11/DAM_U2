import { Component } from '@angular/core';
@Component({
    selector:'my-component',
    templateUrl:'foo.html'
})

export class MyComponent{
    public data : any = {myToggle:true};

    constructor(){

    }

    isClicked(val){
        console.log("Vegetariana: "+ val);
    }

    public getIngredientes(val:number){
        switch(val){
            case 1 :
            
             break;
            case 2 : break;
            case 3 : break;
            case 4 : break;
            case 5 : break;
            case 6 : break;

        }
    }
}